Extract of the VBB GTFS feed for BVG buses, reference day 2026-11-24. Built by make_gtfs_extract.py.
Source: https://vbb.de/vbb-services/api-open-data/datensaetze/ (feed downloaded 2026-11-18, valid 2026-11-18 to 2027-12-11).
